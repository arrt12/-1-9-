using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Skill : MonoBehaviour
{
    float skilTime = 0f;
    [Header("��ų ��Ÿ��")] public float skilMaxTime = 5;
    public GameObject skilObject_1;
    public GameObject spawnPoint;
    public Image skill_1;
    bool isskil_1;
    bool isskil_1Cool;

    void Start()
    {
        skilTime = skilMaxTime;
    }

    void Update()
    {
        PlayerSkil_1();
        PlayerSkil_2();
    }

    void PlayerSkil_1()
    {
        skill_1.fillAmount = skilTime / skilMaxTime;
        if (!isskil_1Cool)
        {
            skilTime += Time.deltaTime;
            if (skilTime >= skilMaxTime)
            {
                isskil_1 = true;
                isskil_1Cool = true;
            }
        }
        Vector3 pos = spawnPoint.transform.position;
        pos.x += 0.4f;
        if (Input.GetKeyDown(KeyCode.Z) && isskil_1)
        {
            GameObject bomb = Instantiate(skilObject_1, pos, Quaternion.Euler(0, 90, 180));
            bomb.GetComponent<Rigidbody>().AddForce(Vector3.up * 5 + Vector3.back * 2, ForceMode.Impulse);
            isskil_1 = false;
            isskil_1Cool = false;
            skilTime = 0;
        }
    }
    void PlayerSkil_2()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {

        }
    }
}
