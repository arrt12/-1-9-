using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Skill : MonoBehaviour
{
    public float skilTime = 0f;
    public float skilTime2 = 0f;
    [Header("��ų ��Ÿ��")] public float skilMaxTime = 5;
    [Header("��ų ��Ÿ��")] public float skilMaxTime_2 = 10;
    public GameObject skilObject_1;
    public GameObject spawnPoint;
    public Image skill_1;
    public Image skill_2;
    bool isskil_1;
    bool isskil_1Cool;
    bool isskil_1Coo2;

    void Start()
    {
        skilTime = skilMaxTime;
        skilTime2 = skilMaxTime_2;
    }

    void Update()
    {
        PlayerSkil_1();
        PlayerSkil_2();
    }

    void PlayerSkil_1()
    {
        skill_1.fillAmount = skilTime / skilMaxTime;
        if (!isskil_1Cool)
        {
            skilTime += Time.deltaTime;
            if (skilTime >= skilMaxTime)
            {
                isskil_1 = true;
                isskil_1Cool = true;
            }
        }
        Vector3 pos = spawnPoint.transform.position;
        pos.x += 0.4f;
        if (Input.GetKeyDown(KeyCode.Z) && isskil_1)
        {
            GameObject bomb = Instantiate(skilObject_1, pos, Quaternion.Euler(0, 90, 180));
            bomb.GetComponent<Rigidbody>().AddForce(Vector3.up * 5 + Vector3.back * 2, ForceMode.Impulse);
            isskil_1 = false;
            isskil_1Cool = false;
            skilTime = 0;
        }
    }
    void PlayerSkil_2()
    {
        Player player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        skill_2.fillAmount = skilTime2 / skilMaxTime_2;
        if (!isskil_1Coo2)
        {
            skilTime2 += Time.deltaTime;
            if (skilTime2 >= skilMaxTime_2)
            {
                isskil_1Coo2 = true;
            }
        }
        if (Input.GetKeyDown(KeyCode.C))
        {
            print("��ų 2����");
            player.Hp = 100;
            isskil_1Coo2 = false;
            skilTime2 = 0;
        }
    }
}
