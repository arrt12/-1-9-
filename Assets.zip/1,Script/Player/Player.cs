using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public float fuel = 1000;
    public float Hp = 100;
    [Header("���ᰡ �پ��� �ֱ�")] public float FuelTime = 0.1f;
    float RFuelTime;
    float fuelMaxTime = 0;
    Animator ani;
    Rigidbody rig;
    public int levelCount = 1;
    public float speed;
    [Header("�̵����� x��ǥ")] public float pox;
    [Header("ȸ�� ��")] public float rotationPoxZ;
    public float attackTime;
    public float attackMaxTime;
    public GameObject bullet;
    public Transform SpawnPoint;
    public Slider fuelBar;
    public Slider HpBar;
    Vector3 bulletPos;

    private void Awake()
    {
        rig = GetComponent<Rigidbody>();
        ani = GetComponent<Animator>();
    }

    void Start()
    {
        RFuelTime = FuelTime;
        levelCount = 1;
    }

    void FixedUpdate()
    {
        PlayerFuel();
        PlayerHp();
        PlayeMove();
        MovementRestrictions();
    }
    private void Update()
    {
        bulletPos = SpawnPoint.position;
        rig.velocity = Vector3.zero;
        Attack();
    }

    void MovementRestrictions()
    {
        var viewPos = Camera.main.WorldToViewportPoint(transform.position);

        if (viewPos.x > 0.95f) viewPos.x = 0.95f;
        if (viewPos.x < 0.05f) viewPos.x = 0.05f;
        if (viewPos.y > 0.95f) viewPos.y = 0.95f;
        if (viewPos.y < 0.05f) viewPos.y = 0.05f;

        var translatePos = Camera.main.ViewportToWorldPoint(viewPos);

        transform.position = new Vector3(translatePos.x, transform.position.y, translatePos.z);
    }

    void PlayeMove()
    {
        float vx = Input.GetAxisRaw("Horizontal");
        float vy = Input.GetAxisRaw("Vertical");
        if (vx > 0)// ������ Ű
        {
            ani.SetBool("RIght", true);
            ani.SetBool("Left", false);
            ani.SetBool("lide", false);
        }
        if (vx < 0)// ���� Ű
        {
            ani.SetBool("Left", true);
            ani.SetBool("RIght", false);
            ani.SetBool("lide", false);
        }
        if (vx == 0)
        {
            ani.SetBool("lide", true);
            ani.SetBool("RIght", false);
            ani.SetBool("Left", false);
        }

        transform.position += new Vector3(vx, 0, vy) * -speed * Time.deltaTime;
    }
    void Attack()
    {
        if (attackTime > 0)
        {
            attackTime -= Time.deltaTime;
        }
        else
        {
            if (Input.GetKey(KeyCode.X))
            {
                attackTime += 0.2f;
                switch (levelCount)
                {
                    case 1:
                        LevelAttack(bullet, 0, -90);
                        break;
                    case 2:
                        LevelAttack(bullet, 0.2f, -90);
                        LevelAttack(bullet, -0.5f, -90);
                        break;
                    case 3:
                        LevelAttack(bullet, 0f, -90);
                        LevelAttack(bullet, 1f, -100);
                        LevelAttack(bullet, -2f, -80);
                        break;
                    case 4:
                        LevelAttack(bullet, 0f, -90);
                        LevelAttack(bullet, 1f, -90);
                        LevelAttack(bullet, -2f, -90);
                        LevelAttack(bullet, 3f, -100);
                        LevelAttack(bullet, -4f, -80);
                        break;
                }
            }
        }
    }

    void PlayerFuel()
    {
        fuelBar.value = fuel;
        FuelTime -= Time.deltaTime;
        if (FuelTime <= fuelMaxTime)
        {
            fuel--;
            FuelTime = RFuelTime;
        }
    }

    void PlayerHp()
    {
        HpBar.value = Hp;
    }

    void LevelAttack(GameObject gameObject, float MathPos, float Angle)
    {
        bulletPos.x += MathPos;
        Instantiate(gameObject, bulletPos, Quaternion.Euler(0, Angle, 180));
    }
}
