using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossDead : MonoBehaviour
{
    enum Dead
    {
        midboss,
        endboss,
    }
    private Boss boss;
    [SerializeField] GameManager gameManager;
    EndBoss endboss;
    [SerializeField] GameObject destructionEffect;//�ı� ����Ʈ
    [SerializeField] GameObject bossObject;
    [SerializeField] Dead dead;
    private void Awake()
    {
        gameManager = FindObjectOfType<GameManager>();
        boss = GetComponent<Boss>(); 
        endboss = GetComponent<EndBoss>(); 
    }

    void Update()
    {
        switch (dead)
        {
            case Dead.midboss:
                BossHp();
                break;
            case Dead.endboss:
                EndBossHp();
                break;
        }

    }
    void BossHp()
    {
        if (boss.Hp <= 0)
        {
            gameManager.gameState = GameState.gaming;
            gameManager.isStage2 = true;
            destructionEffect.SetActive(true);
            bossObject.SetActive(false);
            Destroy(gameObject,1f);
        }
    }
    void EndBossHp()
    {
        if (endboss.Hp <= 0)
        {
            destructionEffect.SetActive(true);
            bossObject.SetActive(false);
            Destroy(gameObject, 1f);
        }
    }
}
