using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossBomb : MonoBehaviour
{
    [SerializeField] float boomTime;
    [SerializeField] float boomMaxTime;
    [SerializeField] public float speed;
    [SerializeField] public float destroyTime;
    [SerializeField] bool isBoom;
    public GameObject bullet;
    public GameObject bomb;
    public Transform SpawnPoint;
    Vector3 eulerPos;

    void Start()
    {
        
    }
    void Update()
    {
        boomTime += Time.deltaTime;
        if (boomTime >= boomMaxTime)
        {
            if (isBoom == false)
            {
                bomb.SetActive(false);
                StartCoroutine(Boom());
            }
            boomTime = 0;
        }
        Move();   
    }
    IEnumerator Boom()
    {
        float plusEuler = 36;
        isBoom = true;
        for (int i = 0; i < 10; i++)
        {
            bulletSpawn(bullet, SpawnPoint, eulerPos);
            eulerPos.y += plusEuler;
        }
        yield return null;
    }
    void Move()
    {
        transform.Translate(new Vector3(speed * Time.deltaTime, 0, 0));
        Destroy(gameObject, destroyTime);
    }
    void bulletSpawn(GameObject gameObject, Transform transform, Vector3 vector)
    {
        Instantiate(gameObject, transform.position, Quaternion.Euler(vector));
    }
}
