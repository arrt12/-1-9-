using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public enum PatternBoss
{
    pattern1,
    pattern2,
    laser
}

public class EndBoss : MonoBehaviour
{
    public Rigidbody rig;
    public float Hp = 100;
    public bool isEndBoss = false;
    public bool islaserAttack = false;
    public bool isPatternAttack = false;
    [SerializeField] bool[] isPatterm;
    [SerializeField] float RoPower;
    Player player;
    [SerializeField] GameObject axis;
    [SerializeField] GameObject attack2Prefab;
    [SerializeField] GameObject GetGameObject;
    public PatternBoss getPattern;
    LaserAttack laserAttack;

    [SerializeField] int AttacklCount = 0;
    public int LaserCount = 0;
    float time;
    float timeMax = 4.5f;
    private bool isRoAttack = false;//���鼭 ����
    private bool isSpin = false;
    private bool isHit = false;
    private bool isdead = false;
    private bool isMove = false;
    private bool isAttack_3 = false;
    private bool isAttack_3ing = false;
    [SerializeField] Transform PatternAttackSpawn;
    [SerializeField] GameObject attackRang_3;
    [SerializeField] GameObject[] bulletsObjects;

    private void Awake()
    {
        rig = GetComponent<Rigidbody>();
        laserAttack = GetComponent<LaserAttack>();
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
    }


    void Start()
    {
        //int a = Random.Range(0, 3);
        //switch (a)
        //{
        //    case 0:
        //        getPattern = PatternBoss.pattern1;
        //        break;
        //    case 1:
        //        getPattern = PatternBoss.pattern2;
        //        break;
        //    case 2:
        //        getPattern = PatternBoss.pattern3;
        //        break;
        //}
    }

    void Update()
    {
        if (!isEndBoss)
            return;
        if (isdead)
            return;
        if (isPatternAttack)
        {
            if (getPattern != PatternBoss.laser)
                return;
            BossPatterm1();
        }
        else
        {
            laserAttack.produceCount = 0;
            laserAttack.count = 0;
            time = 0;
        }
        if (LaserCount == 4)
        {
            isPatternAttack = false;
            BossManager();
            transform.rotation = Quaternion.identity;
            axis.transform.rotation = Quaternion.identity;
            LaserCount = 0;
            laserAttack.produceCount = 0;
            laserAttack.count = 0;
            time = 0;
        }
        time += Time.deltaTime;
        if (time >= timeMax)
        {
            laserAttack.produceCount = 0;
            laserAttack.count = 0;
            time = 0;
        }

        switch (getPattern)
        {
            case PatternBoss.pattern1:
                BossPatterm2();
                break;
            case PatternBoss.pattern2:
                BossPatterm3();
                break;
            case PatternBoss.laser:
                isPatternAttack = true;
                break;
        }
        EndBossObj();
        DeadEnd();
    }
    public void BossManager()
    {
        isPatterm[0] = false;
        isPatterm[1] = false;
        isPatternAttack = false;
        float RandMode = Random.Range(0, 3);
        switch (RandMode)
        {
            case 0:
                getPattern = PatternBoss.laser;
                break;
            case 1:
                getPattern = PatternBoss.pattern1;
                break;
            case 2:
                getPattern = PatternBoss.pattern2;
                break;
        }
    }
    void BossPatterm1()
    {
        islaserAttack = true;
        laserAttack.AttackRange();
    }

    void BossPatterm2()
    {
        if (isPatterm[0] == false)
        {
            print("�ڷ�ƾ����");
            StartCoroutine(Patterm_2());
        }
        if (isRoAttack)
        {
            transform.Rotate(0, 0, 700 * Time.deltaTime);
        }
    }

    IEnumerator Patterm_2()//������� ���鼭
    {
        isPatterm[0] = true;
        isPatterm[1] = false;
        yield return new WaitForSeconds(1f);
        for (int i = 0; i <= 30; i++)
        {
            transform.rotation = Quaternion.Euler(-i * 3, 0, 0);
            yield return null;
        }
        for (int i = 0; i <= 10; i++)
        {
            transform.rotation = Quaternion.Euler(-90, 0, -i * 4);
            yield return null;
        }
        isRoAttack = true;
        Camera.main.GetComponent<ShakeCamera>().Setup(0.3f, 0.3f);
        for (int i = 0; i < 15; i++)
        {
            for (int j = 0; j < 30; j++)
            {
                Instantiate(attack2Prefab, PatternAttackSpawn.position, Quaternion.Euler(PatternAttackSpawn.eulerAngles));
                yield return new WaitForSecondsRealtime(0.02f);
            }
        }
        isRoAttack = false;
        transform.rotation = Quaternion.identity;
        yield return new WaitForSecondsRealtime(1f);
        transform.rotation = Quaternion.identity;
        axis.transform.rotation = Quaternion.identity;
        BossManager();
    }

    void BossPatterm3()
    {
        if (isPatterm[1] == false)
        {
            StartCoroutine(Patterm_3());
        }
        if (isAttack_3)
        {
            StartCoroutine(Pattern_3Attack());
            isAttack_3 = false;
        }
        if (isAttack_3ing && AttacklCount != 4)
        {
            StartCoroutine(Pattern_3Attacking());
            isAttack_3ing = false;
        }
        if (isSpin)
        {
            axis.transform.Rotate(0, 0, 900 * Time.deltaTime);
        }
        if (isMove)
        {
            transform.Translate(0, 100 * Time.deltaTime, 0);
        }
        if (AttacklCount == 4)
        {
            transform.rotation = Quaternion.Euler(0, 0, 0);
            transform.position = new Vector3(0, 0, -10);
            isAttack_3ing = false;
            isMove = false;
            isSpin = false;
            AttacklCount = 0;
            Invoke("BossManager", 1f);
            transform.rotation = Quaternion.identity;
            axis.transform.rotation = Quaternion.identity;
        }
    }

    IEnumerator Patterm_3()//���� 3 ����
    {
        isPatterm[0] = false;
        isPatterm[1] = true;
        yield return new WaitForSecondsRealtime(0.1f);
        yield return new WaitForSecondsRealtime(1f);
        for (int i = 0; i <= 30; i++)
        {
            transform.rotation = Quaternion.Euler(i * 3, transform.rotation.y, transform.rotation.z);
            yield return null;
        }
        isSpin = true;
        isAttack_3 = true;
    }
    IEnumerator Pattern_3Attack()//����3 ù ����
    {
        for (int i = 0; i < 10; i++)
        {
            attackRang_3.SetActive(true);
            yield return new WaitForSecondsRealtime(0.1f);
            attackRang_3.SetActive(false);
            yield return new WaitForSecondsRealtime(0.1f);
        }
        yield return new WaitForSecondsRealtime(0.3f);
        isMove = true;
        Camera.main.GetComponent<ShakeCamera>().Setup(0.2f, 0.2f);
        yield return new WaitForSecondsRealtime(1f);
        isMove = false;
        isAttack_3ing = true;
    }

    IEnumerator Pattern_3Attacking()
    {
        switch (AttacklCount)
        {
            case 0:
                transform.position = new Vector3(-45f, 0f, 5f);
                transform.rotation = Quaternion.Euler(90f, 90f, 0);
                break;
            case 1:
                transform.position = new Vector3(-45f, 0, -5f);
                transform.rotation = Quaternion.Euler(90f, 90f, 0);
                break;
            case 2:
                transform.position = new Vector3(45f, 0, -5f);
                transform.rotation = Quaternion.Euler(90f, -90f, 0);
                break;
            case 3:
                transform.position = new Vector3(45f, 0, 5f);
                transform.rotation = Quaternion.Euler(90f, -90f, 0);
                break;
        }
        for (int i = 0; i < 10; i++)
        {
            attackRang_3.SetActive(true);
            yield return new WaitForSecondsRealtime(0.1f);
            attackRang_3.SetActive(false);
            yield return new WaitForSecondsRealtime(0.1f);
        }
        yield return new WaitForSecondsRealtime(0.3f);
        isMove = true;
        Camera.main.GetComponent<ShakeCamera>().Setup(0.2f, 0.2f);
        yield return new WaitForSecondsRealtime(1f);
        isMove = false;
        if (AttacklCount <= 4)
        {
            AttacklCount++;
            isAttack_3ing = true;
        }
    }

    void EndBossObj()
    {
        if (laserAttack.isFollow)
        {
            if (getPattern != PatternBoss.laser)
                return;
            Quaternion targetRotation = Quaternion.LookRotation(player.transform.position - axis.transform.position);
            axis.transform.rotation = targetRotation;
        }
    }
    public void Hit(float HitDamage)
    {
        if (!isHit)
        {
            Hp -= HitDamage;
            StartCoroutine("HitAni");
            isHit = true;
        }
    }
    IEnumerator HitAni()
    {
        GetGameObject.SetActive(false);
        yield return new WaitForSeconds(0.05f);
        GetGameObject.SetActive(true);
        yield return new WaitForSeconds(0.05f);
        isHit = false;
    }
    void DeadEnd()
    {
        if (Hp <= 0)
        {
            Camera.main.GetComponent<ShakeCamera>().Setup(0.7f, 0.7f);
            isdead = true;
            //Camera.main.GetComponent<ShakeCamera>().Setup(0.5f, 0.5f); -> ���߿� �߰��ϱ�
            bulletsObjects = GameObject.FindGameObjectsWithTag("MonsterBullet");
            if (bulletsObjects == null)
                return;
            foreach (var item in bulletsObjects)    
            {
                Destroy(item);
            }
        }
    }


}
