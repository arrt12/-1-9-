using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserAttack : MonoBehaviour
{
    public int count;
    public int produceCount;
    [SerializeField] EndBoss boss;
    [SerializeField] float Starttime;
    [SerializeField] float MaxStartime;
    [SerializeField] GameObject attackRang;
    [SerializeField] GameObject laser;
    [SerializeField] GameObject axis;
    [SerializeField] Transform laserSpawn;
    public bool isFollow = true;
    public void AttackRange()
    {
        if (!boss.islaserAttack)
            return;

        Starttime += Time.deltaTime;
        if (Starttime >= MaxStartime)
        {
            count++;
            Starttime = 0;
        }
        if (count <= 11)
        {
            if (count % 2 == 0)//¦��
            {
                attackRang.gameObject.SetActive(true);
            }
            else//Ȧ��
            {
                attackRang.gameObject.SetActive(false);
            }
            if (count == 11)
            {
                isFollow = false;
            }
        }
        else if(count >= 16)
        {
            boss.islaserAttack = false;
            attackRang.gameObject.SetActive(false);
            if (produceCount <= 0)
            {
                Camera.main.GetComponent<ShakeCamera>().Setup(0.3f,0.3f);
                Instantiate(laser ,laserSpawn.position, Quaternion.Euler(axis.transform.eulerAngles));
                produceCount++; 
                boss.LaserCount++;
                 isFollow = true;
            }
        }
    }
}
