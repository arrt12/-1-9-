using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : MonoBehaviour
{
    Vector3 dir;
    bool isDead = false;
    MeteorScript meteorScript;
    Rigidbody rig;
    public float Hp = 100;
    public GameObject SpawnPoint;
    public GameObject Player;
    //���� 1
    [Header("����1")]
    [SerializeField] int moveCount = 0;
    [SerializeField] private float speed;
    [SerializeField] private float destroyTime;
    public float attackTime_1;
    public float attackMaxTime_1;
    public GameObject bullet_1;
    public GameObject axis;
    //
    [Header("���׿�")]
    public float rotatePower;
    int RotateCount;
    public float MeteorSpeed;
    public float MeteorDestroyTime;
    Vector3 target;
    [Header("����2")]
    public GameObject bullet_2;
    public Transform SpawnPoint_2;
    [SerializeField]float Monster_2Speed;
    [SerializeField]float MonsterrotatePower;
    [SerializeField]float MonsterDestoryTime;
    [SerializeField]float attacktime_2;
    [SerializeField]float attackMaxTime_2;
    [Header("�ǰ�")]
    [SerializeField] bool isHit;
    [SerializeField] GameObject[] bulletsObjects;
    [SerializeField] GameObject GetGameObject;
    enum MosterType
    {
        monster1,
        monster2,
        monster3,
    }

    [SerializeField] MosterType mosterType;

    private void Awake()
    {
        meteorScript = GetComponent<MeteorScript>();
        rig = GetComponent<Rigidbody>();
        Player = GameObject.FindGameObjectWithTag("Player");
    }

    void Start()
    {
        target = Player.transform.position;
        target.z += 5;
    }

    void Update()
    {
        if (isDead)
            return;
        ScreenOutDestroy();
        DeadEnd();
        switch (mosterType)
        {
            case MosterType.monster1:
                Attack();
                Move1();
                Quaternion targetRotation = Quaternion.LookRotation(Player.transform.position - axis.transform.position);
                axis.transform.rotation = targetRotation;
                break;
            case MosterType.monster2:
            basicObject(new Vector3(rotatePower, 0, 0), MeteorDestroyTime);
            if (RotateCount <= 0)
            {
                MeteorDirection();
                RotateCount++;
            }
            if (meteorScript.isMove)
            {
                rig.velocity = dir.normalized * MeteorSpeed;
            }
                break;
            case MosterType.monster3:
                basicObject(new Vector3(0, MonsterrotatePower, 0), MonsterDestoryTime);
                Monster_2();
                Monster_2Move();
                break;
        }
    }

    void Attack()
    {
        attackTime_1 += Time.deltaTime;
        if (attackTime_1 >= attackMaxTime_1)
        {
            Quaternion targetRotation = Quaternion.LookRotation(Player.transform.position - axis.transform.position);
            moveCount++;
            Instantiate(bullet_1, SpawnPoint.transform.position, Quaternion.Euler(axis.transform.eulerAngles));
            attackTime_1 = 0;
        }
    }
    void Move1()
    {
        int MoveRandom = Random.Range(0, 2);
        if (moveCount <= MoveRandom)
        {
            MoveFunction(speed, destroyTime);
        }
        else
        {
            MoveFunction(speed * 0.5f, destroyTime);
        }
    }

    void basicObject (Vector3 rotatePower, float MeteorDestroyTime)
    {
        transform.Rotate(rotatePower * Time.deltaTime);
        Destroy(gameObject, MeteorDestroyTime);
    }

    void MeteorDirection()
    {
        dir = Player.transform.position - transform.position;
        dir.y = 0;
        Quaternion rot = Quaternion.LookRotation(dir.normalized);
        transform.rotation = rot;
    }

    void Monster_2()
    {

        attacktime_2 += Time.deltaTime;
        if (attacktime_2 >= attackMaxTime_2)
        {
            Instantiate(bullet_2, SpawnPoint_2.position, Quaternion.Euler(transform.eulerAngles));
            attacktime_2 = 0;
        }
    }
    void Monster_2Move()
    { 
        var viewPos = Camera.main.WorldToViewportPoint(transform.position);

        if (viewPos.x < -0.3f) Destroy(gameObject);
        if (viewPos.y < -0.3f) Destroy(gameObject);

        rig.velocity = Vector3.right * Monster_2Speed;
    }

    void MoveFunction(float speed, float destroyTime)
    {
        Vector3 moveVec = new Vector3(-speed * Time.deltaTime, 0, 0);
        transform.Translate(moveVec);
        Destroy(gameObject, destroyTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (isDead)
            return;
        if (other.gameObject.CompareTag("Wall"))
        {
            Monster_2Speed *= -1;
        }
    }

    public void Hit(float HitDamage)
    {
        if (isDead)
            return;
        if (!isHit)
        {
            Hp -= HitDamage;
            StartCoroutine("HitAni");
            isHit = true;
        }
    }
    void DeadEnd()
    {
        if (Hp <= 0)
        {
            isDead = true;
            bulletsObjects = GameObject.FindGameObjectsWithTag("MonsterBullet");
            if (bulletsObjects == null)
                return;
            foreach (var item in bulletsObjects)
            {
                Destroy(item);
            }
        }
    }
    void ScreenOutDestroy()
    {
        var viewPos = Camera.main.WorldToViewportPoint(transform.position);

        if (viewPos.x > 1.2f) Destroy(gameObject);
        if (viewPos.x < -0.2f) Destroy(gameObject);
        if (viewPos.y > 1.2f) Destroy(gameObject);
        if (viewPos.y < -0.2f) Destroy(gameObject);
    }
    IEnumerator HitAni()
    {
        GetGameObject.SetActive(false);
        yield return new WaitForSeconds(0.05f);
        GetGameObject.SetActive(true);
        yield return new WaitForSeconds(0.05f);
        isHit = false;
    }
}
