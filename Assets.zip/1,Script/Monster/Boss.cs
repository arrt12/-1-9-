using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss : MonoBehaviour
{   public bool isMidBoss = false;
    [SerializeField]public float Hp = 100;
    private Transform player;
    public Rigidbody rig;
    int count = 0;
    public PatternRange2 PatternRange;
    [SerializeField] bool[] isPatterm;
    [Header("����1")]
    public Transform SpawnPoint;
    public GameObject bullet;
    [Header("����2")]
    public Transform[] SpawnPoints_2;
    public GameObject Bombbullet;
    public GameObject attackRang;
    [SerializeField] float speed;
    Vector3 EulerPos;
    Vector3 RPos;
    [SerializeField]bool isStartPattern3 = false;
    [SerializeField]bool isStart = false;
    [Header("�ǰ�")]
    [SerializeField] bool isHit;
    [SerializeField] GameObject GetGameObject;
    [Header("���")]
    [SerializeField] GameObject[] bulletsObjects;
    enum Pattern
    {
        patterm1,
        patterm2,
        patterm3,
    }
    
    private void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        rig = GetComponent<Rigidbody>();
    }

    [SerializeField] Pattern getPattern;
    void Start()
    {
        int a = Random.Range(0,3);
        RPos = transform.position;
        RPos.y += 25;
        switch (a)
        {
            case 0:
                getPattern = Pattern.patterm1;
                break;
            case 1:
                getPattern = Pattern.patterm2;
                break;
            case 2:
                getPattern = Pattern.patterm3;
                break;
        }
    }

    void Update()
    {
        if (!isMidBoss)
            return;
        if (rig.useGravity == false)
        {
            rig.velocity = Vector3.zero;
        }
        switch (getPattern)
        {
            case Pattern.patterm1:
                BossPatterm1();
                break;
            case Pattern.patterm2:
                BossPatterm2();
                break;
            case Pattern.patterm3:
                BossPatterm3();
                break;
        }
        DeadEnd();
    }
    void bossManager()
    {
        float RandMode = Random.Range(0,3);
        switch (RandMode)
        {
            case 0:
                getPattern = Pattern.patterm1;
                isPatterm[0] = false;
                count = 0;
                break;
            case 1:
                getPattern = Pattern.patterm2;
                isPatterm[1] = false;
                count = 0;
                break;
            case 2:
                getPattern = Pattern.patterm3;
                isPatterm[2] = false;
                count = 0;
                break;
        }
    }

    void BossPatterm1()
    {
        if (isPatterm[0] == false)
        {
            StartCoroutine(Patterm_1());
        }
    }

    IEnumerator Patterm_1()
    {
        float rangEuler;
        isPatterm[0] = true;
        isPatterm[1] = false; 
        isPatterm[2] = false;
        for (int i = 0; i < 2; i++)
        {
            for (int j = 0; j < 50; j++)
            {
                rangEuler = Random.Range(-60,60);
                EulerPos = new Vector3(transform.eulerAngles.x, rangEuler, transform.eulerAngles.z);
                bulletSpawn(bullet, SpawnPoint, EulerPos);
                yield return new WaitForSeconds(0.09f);
            }
        }
        Invoke("bossManager",3f);
        print("�κ�ũ ����");
    }

    void BossPatterm2()
    {
        if (isPatterm[1] == false)
        {
            StartCoroutine(Patterm_2());
        }
    }

    IEnumerator Patterm_2()
    { 
        float rangEuler;
        isPatterm[1] = true;
        isPatterm[0] = false;
        isPatterm[2] = false;
        EulerPos = Vector3.zero;
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 2; j++)
            { 
                foreach (var item in SpawnPoints_2)
                {
                    rangEuler = Random.Range(-25, 25);
                    EulerPos = new Vector3(transform.eulerAngles.z, rangEuler, transform.eulerAngles.z);
                    bulletSpawn(Bombbullet, item, EulerPos);
                }
                yield return new WaitForSeconds(1f);
            }
        }
        Invoke("bossManager", 3f);
        print("�κ�ũ ����");
    }

    void BossPatterm3()
    {
        if (isStartPattern3 == false && !isStart)
        {
            transform.position = new Vector3(player.position.x, 0, -21.09f);
        }
        if (isPatterm[2] == false)
        {
            isStart = false;
            isStartPattern3 = false;
            StartCoroutine(Patterm_3());
        }
        if (PatternRange.isMove)
        {
            StartCoroutine(EndPatterm_3());
        }
        if (transform.position.y <= 0 && !PatternRange.isMove && isStart)
        {
            if (count == 0)
            {
                Invoke("bossManager", 4.5f);
                count++;
            }
            transform.position = new Vector3(0,0,-21.09f);
            rig.useGravity = false;
        }
    }

    IEnumerator Patterm_3()
    {
        isPatterm[2] = true;    
        isPatterm[0] = false;   
        isPatterm[1] = false;
        attackRang.SetActive(true);
        yield return null;
    }

    IEnumerator EndPatterm_3()
    {
        isStart = true;
        isStartPattern3 = true;
        yield return new WaitForSeconds(0.5f);
        transform.Translate(Vector3.forward *speed *Time.deltaTime);
        yield return new WaitForSeconds(1.0f);
        PatternRange.isMove = false;
        yield return null;
        transform.position = RPos;
        yield return null;
        rig.useGravity = true;
    }

    void bulletSpawn(GameObject gameObject,Transform transform,Vector3 vector)
    {
        Instantiate(gameObject, transform.position, Quaternion.Euler(vector));
    }

    public void Hit(float HitDamage)
    {
        if (!isHit)
        {
            Hp -= HitDamage;
            StartCoroutine("HitAni");
            isHit = true;
        }
    }

    IEnumerator HitAni()
    {
        GetGameObject.SetActive(false);
        yield return new WaitForSeconds(0.05f);
        GetGameObject.SetActive(true);
        yield return new WaitForSeconds(0.05f);
        isHit = false;
    }
    void DeadEnd()
    {
        if (Hp <=0)
        {
            Camera.main.GetComponent<ShakeCamera>().Setup(0.1f, 0.5f);
            bulletsObjects = GameObject.FindGameObjectsWithTag("MonsterBullet");
            if (bulletsObjects == null)
                return;
            foreach (var item in bulletsObjects)
            {
                Destroy(item);
            }
        }
    }
}
