using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dead : MonoBehaviour
{
    Monster Monster;
    [SerializeField] GameObject destructionEffect;//�ı� ����Ʈ
    [SerializeField] GameObject bossObject;
    private void Awake()
    {
        Monster = GetComponent<Monster>();
    }

    void Start()
    {
    }

    void Update()
    {
        BossHp();
    }
    void BossHp()
    {
        if (Monster.Hp <= 0)
        {
            bossObject.SetActive(false);
            destructionEffect.SetActive(true);
            Destroy(gameObject, 3f);
        }
    }
}
