using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moster : MonoBehaviour
{
    Vector3 dir;
    MeteorScript meteorScript;
    Rigidbody rig;
    public float Hp;
    public GameObject SpawnPoint;
    public GameObject Player;
    //���� 1
    [Header("����1")]
    [SerializeField] int moveCount = 0;
    [SerializeField] private float speed;
    [SerializeField] private float destroyTime;
    public float attackTime_1;
    public float attackMaxTime_1;
    public GameObject bullet_1;
    //
    [Header("���׿�")]
    public float rotatePower;
    int RotateCount;
    public float MeteorSpeed;
    public float MeteorDestroyTime;
    Vector3 target;
    [Header("����2")]
    public GameObject bullet_2;
    public Transform SpawnPoint_2;
    [SerializeField]float Monster_2Speed;
    [SerializeField]float MonsterrotatePower;
    [SerializeField]float MonsterDestoryTime;
    [SerializeField]float attacktime_2;
    [SerializeField]float attackMaxTime_2;

    enum MosterType
    {
        monster1,
        monster2,
        monster3,
    }

    [SerializeField] MosterType mosterType;

    private void Awake()
    {
        meteorScript = GetComponent<MeteorScript>();
        rig = GetComponent<Rigidbody>();
        Player = GameObject.FindGameObjectWithTag("Player");
    }

    void Start()
    {
        target = Player.transform.position;
        target.z += 5;
    }

    void Update()
    { 
        switch (mosterType)
        {
            case MosterType.monster1:
                Attack();
                Move1();
                break;
            case MosterType.monster2:
            basicObject(new Vector3(rotatePower, 0, 0), MeteorDestroyTime);
            if (RotateCount <= 0)
            {
                MeteorDirection();
                RotateCount++;
            }
            if (meteorScript.isMove)
            {
                rig.velocity = dir.normalized * MeteorSpeed;
            }
                break;
            case MosterType.monster3:
                basicObject(new Vector3(0, MonsterrotatePower, 0), MonsterDestoryTime);
                Monster_2();
                Monster_2Move();
                break;
        }
    }

    void Attack()
    {
        int attackRandom;
        int attackRandomRange;
        attackTime_1 += Time.deltaTime;
        if (attackTime_1 >= attackMaxTime_1)
        {
            attackRandom = Random.Range(1, 3);
            attackRandomRange = Random.Range(80, 101);
            moveCount++;
            switch (attackRandom)
            {
                case 1:
                    Instantiate(bullet_1, SpawnPoint.transform.position, Quaternion.Euler(0, attackRandomRange, 180));
                    break;
                case 2:
                    Instantiate(bullet_1, SpawnPoint.transform.position, Quaternion.Euler(0, 80, 180));
                    Instantiate(bullet_1, SpawnPoint.transform.position, Quaternion.Euler(0, 90, 180));
                    Instantiate(bullet_1, SpawnPoint.transform.position, Quaternion.Euler(0, 100, 180));
                    break;
            }
            attackTime_1 = 0;
        }
    }
    void Move1()
    {
        int MoveRandom = Random.Range(0, 2); ;
        if (moveCount <= MoveRandom)
        {
            MoveFunction(speed, destroyTime);
        }
    }
    void basicObject (Vector3 rotatePower, float MeteorDestroyTime)
    {
        transform.Rotate(rotatePower * Time.deltaTime);
        Destroy(gameObject, MeteorDestroyTime);
    }
    void MeteorDirection()
    {
        dir = Player.transform.position - transform.position;
        dir.y = 0;
        Quaternion rot = Quaternion.LookRotation(dir.normalized);
        transform.rotation = rot;
    }
    void Monster_2()
    {
        //���⼭ ���� �ٽ��ϱ�
        attacktime_2 += Time.deltaTime;
        if (attacktime_2 >= attackMaxTime_2)
        {
            Instantiate(bullet_2, SpawnPoint_2.position, Quaternion.Euler(0, transform.rotation.eulerAngles.y, 180));
            attacktime_2 = 0;
        }
    }
    void Monster_2Move()
    { 
        var viewPos = Camera.main.WorldToViewportPoint(transform.position);

        if (viewPos.x > 0.95f) Monster_2Speed *= -1;
        if (viewPos.x < 0.05f) Monster_2Speed *= -1;
        if (viewPos.y > 0.95f) Monster_2Speed *= -1;
        if (viewPos.y < 0.05f) Monster_2Speed *= -1;


        var translatePos = Camera.main.ViewportToWorldPoint(viewPos);

        rig.velocity = Vector3.right * Monster_2Speed
            ;
    }
    void MoveFunction(float speed, float destroyTime)
    {
        Vector3 moveVec = new Vector3(-speed * Time.deltaTime, 0, 0);
        transform.Translate(moveVec);
        Destroy(gameObject, destroyTime);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Wall"))
        {
            Monster_2Speed *= -1;
        }
    }
}
