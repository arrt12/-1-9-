using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossStart : MonoBehaviour
{
    enum BossStartPlay
    {
        midBoss,
        endBoss
    }
    private int count = 0;
    private int EndCount = 0;
    [SerializeField] GameObject BossPrefab;
    private Boss boss;
    private EndBoss endBoss;
    [SerializeField] GameManager gameManager;
    [SerializeField] BossStartPlay bossStart;
    
    void Update()
    {
        if (gameManager.gameState == GameState.starting || gameManager.gameState == GameState.gaming)
            return;
        switch (bossStart)
        {
            case BossStartPlay.midBoss:
                MidBossIntro();
                break;
            case BossStartPlay.endBoss:
                EndBossIntro();
                break;
        }
    }
    void MidBossIntro()
    {
        if (gameManager.gameState != GameState.midBoss)
            return;
        if (count <= 0)
        {
            Instantiate(BossPrefab,transform.position,Quaternion.identity);
            boss = GameObject.FindGameObjectWithTag("MidBoss").GetComponent<Boss>();
            boss.rig.useGravity = true;
            count++;
        }
        if (boss.transform.position.y <= 0 && EndCount <= 0)
        { 
            boss.rig.useGravity = false;
            boss.rig.velocity = Vector3.zero;
            boss.transform.position = new Vector3(0, 0, -21.09f);
            boss.isMidBoss = true;
            Camera.main.GetComponent<ShakeCamera>().Setup(0.6f, 0.6f);
            EndCount++;
        }
        if (boss.Hp <= 0)
        {
            Destroy(gameObject);
        }
    }
    void EndBossIntro()
    {
        if (gameManager.gameState != GameState.EndBoss)
            return;
        if (count <= 0)
        {
            Instantiate(BossPrefab, transform.position, Quaternion.identity);
            endBoss = GameObject.FindGameObjectWithTag("EndBoss").GetComponent<EndBoss>();
            endBoss.rig.useGravity = true;
            count++;
        }
        if (endBoss.transform.position.y <= 0 && EndCount <= 0)
        {
            endBoss.rig.useGravity = false;
            endBoss.rig.velocity = Vector3.zero;
            endBoss.transform.position = new Vector3(0, 0, -10);
            endBoss.isEndBoss = true;
            Camera.main.GetComponent<ShakeCamera>().Setup(0.6f, 0.6f);
            EndCount++;
        }
        if (endBoss.Hp <= 0)
        {
            Destroy(gameObject);
        }
    }
}
