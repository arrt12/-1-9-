using System.Collections;
using System.Collections.Generic;
using UnityEngine;

enum Creation
{
    Monster1,
    Monster2,
}
enum IsCreation
{
    isTrue,
    isfloat,
}
public class MonsterCreationManager : MonoBehaviour
{
    [SerializeField] GameManager gameManager;
    [SerializeField] float time;
    [Header("�ִ� �����ð�")]
    [SerializeField] float MaxTime;
    [SerializeField] GameObject monster;
    [SerializeField]Creation creation;
    public bool isC = false;
    [SerializeField] IsCreation isCreation;
    private void Start()
    {
        isC = true;
    }

    void Update()
    {
        switch (isC)
        {
            case true:
                isCreation = IsCreation.isTrue;
                break;
            case false:
                isCreation = IsCreation.isfloat;
                break;
        }

        if (gameManager.gameState == GameState.starting)
            return;
        if (isCreation == IsCreation.isfloat)
            return;
        switch (creation)
        {
            case Creation.Monster1:
                UnitCreation();
                break;
            case Creation.Monster2:
                Unit2Creation();
                break;
        }
    }

    void UnitCreation()
    {
        float randRang;
        time += Time.deltaTime;
        Vector3 pos = transform.position;
        if (time >= MaxTime)
        {
            randRang = Random.Range(-5f, -29.5f);
            pos.z = randRang;
            CreationFunction(monster, pos, new Vector3(0, 0, 180));
            time = 0;
        }
    }
    void Unit2Creation()
    {
        float randRang;
        float angleRang;
        time += Time.deltaTime;
        Vector3 pos = transform.position;
        if (time >= MaxTime)
        {
            randRang = Random.Range(-20f, 20f);
            angleRang = Random.Range(-100f, -80f);
            pos.x = randRang;
            CreationFunction(monster, pos ,new Vector3(0,angleRang, 180));
            time = 0;
        }
    }


    void CreationFunction(GameObject gameObject, Vector3 _transform, Vector3 vector)
    {
        Instantiate(gameObject, _transform, Quaternion.Euler(vector));
    }
}
