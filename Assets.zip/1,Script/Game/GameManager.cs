using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum GameState
{
    starting,
    gaming,
    midBoss,
    EndBoss,
}

public class GameManager : MonoBehaviour
{
    public bool isStage2 = false;
    Vector3 UIpos = new Vector3(0, 471, 0);
    [SerializeField] float moveSpeed = 10f;
    [SerializeField] float gameTime;
    [SerializeField] float gameTime_2;
    public RectTransform rect;
    public RectTransform UIrect;
    bool isStart;
    public GameState gameState;
    void Start()
    {
        gameState = GameState.starting;
    }

    void Update()
    {
        if (isStart)
        {
            rect.anchoredPosition = Vector2.Lerp(rect.anchoredPosition, new Vector3(0, -750, 0), moveSpeed * Time.deltaTime);
            if (rect.anchoredPosition.y <= -749)
            {
                rect.anchoredPosition = new Vector3(0, -750, 0);
                isStart = false;
                gameState = GameState.gaming;
            }
            Invoke(nameof(DownEffect), 2f);
        }
        PlayerGameTime();
    }
    
    public void StartButton()
    {
        print("Start");
        isStart = true;
    }
    public void ExitButton()
    {
        print("exit");
        Application.Quit();
    }
    public void SettingButton()
    {
        print("seting");
    }
    void DownEffect()
    {
        UIrect.anchoredPosition = Vector2.Lerp(UIrect.anchoredPosition, UIpos, moveSpeed * Time.deltaTime);
        if (UIrect.anchoredPosition.y <= 470)
        {
            UIrect.anchoredPosition = UIpos;
        }
    }
    void PlayerGameTime()
    {
        if (gameState == GameState.starting)
            return;
        if (!isStage2)
            gameTime += Time.deltaTime;
        if (gameTime >= 60 && !isStage2)//�߰� ���� ����
        {
            Monster[] monster = FindObjectsOfType<Monster>();
            MonsterCreationManager[] managers = FindObjectsOfType<MonsterCreationManager>();
            foreach (var item in monster)
            {
                Destroy(item.gameObject);
            }
            foreach (var item in managers)
            {
                item.isC = false;
            }
            gameState = GameState.midBoss;
        }

        if (gameState == GameState.gaming && isStage2)//�������� 2
        {
            gameTime_2 += Time.deltaTime;
            Monster[] monster = FindObjectsOfType<Monster>();
            MonsterCreationManager[] managers = FindObjectsOfType<MonsterCreationManager>();
            foreach (var item in monster)
            {
                Destroy(item.gameObject);
            }

            foreach (var item in managers)
            {
                item.isC = true;
            }

            if (gameTime_2 >= 60)//�������� 2 �ð��� 60�� �Ѵ´ٸ�?
            {
                foreach (var item in managers)
                {
                    item.isC = false;//��� ���� �Ŵ��� �ߴ�
                }
                gameState = GameState.EndBoss;
            }
        }
    }
}
