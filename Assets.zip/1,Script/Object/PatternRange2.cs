using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PatternRange2 : MonoBehaviour
{
    public bool isMove = false;
    [SerializeField]int count;
    [SerializeField] float Starttime;
    [SerializeField] float MaxStartime;
    public GameObject atRange;

    void Update()
    {
        attackRange();
    }
    void attackRange()
    {
        Starttime += Time.deltaTime;
        if (count <= 17)
        {
            if (Starttime >= MaxStartime)
            {
                count++;
                Starttime = 0;
            }
            if (count % 2 == 0)//¦��
            {
                atRange.SetActive(true);
            }
            else//Ȧ��
            {
                atRange.SetActive(false);
            }
        }
        else
        { 
            count = 0;
            isMove = true;
            gameObject.SetActive(false);
            return;
        }
    }
}
