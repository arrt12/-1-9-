using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boom : MonoBehaviour
{

    [Header("������Ʈ ���� �ð�")] public float destroyTime;
    public GameObject bumb;
    public GameObject bumbEftect;
    public float time;
    [Header("������ �ð�")] public float Maxtime;

    void Update()
    {
        Bumb();
        Move();
    }

    public void Bumb()
    {
        Monster[] MonsterGameObject = FindObjectsOfType<Monster>();
        GameObject[] MonsterBullets = GameObject.FindGameObjectsWithTag("MonsterBullet");
        time += Time.deltaTime;
        if (time >= Maxtime)
        {
            bumb.SetActive(false);
            bumbEftect.SetActive(true);
            Camera.main.GetComponent<ShakeCamera>().Setup(0.7f, 0.7f);
            foreach (var item in MonsterGameObject)
            {
                Destroy(item.gameObject);
            }
            foreach (var item in MonsterBullets)
            {
                Destroy(item);
            }
            time = 0;
        }
    }

    public void Move()
    { 
        Destroy(gameObject, destroyTime);
    }
}
