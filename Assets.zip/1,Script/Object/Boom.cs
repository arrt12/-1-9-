using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boom : MonoBehaviour
{

    [Header("������Ʈ ���� �ð�")] public float destroyTime;
    public GameObject bumb;
    public GameObject bumbEftect;
    public float time;
    [Header("������ �ð�")] public float Maxtime;

    void Update()
    {
        Bumb();
        Move();
    }

    public void Bumb()
    {
        time += Time.deltaTime;
        if (time >= Maxtime)
        {
            bumb.SetActive(false);
            bumbEftect.SetActive(true);
            Camera.main.GetComponent<ShakeCamera>().Setup(0.7f, 0.7f);
            time = 0;
        }
    }

    public void Move()
    { 
        Destroy(gameObject, destroyTime);
    }
}
