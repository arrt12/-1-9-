using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Star : MonoBehaviour
{
    [SerializeField] public float speed;
    [SerializeField] public float destroyTime;
    void Start()
    {

    }
    void Update()
    {
        transform.Translate(new Vector3(0, 0, speed * Time.deltaTime));
        Destroy(gameObject, destroyTime);
    }
}
