using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missile : MonoBehaviour
{
    Rigidbody rig;
    float time;
    [SerializeField]float maxTime;
    private void Awake()
    { 
        rig = GetComponent<Rigidbody>();
    }
    void Update()
    {
        time += Time.deltaTime;
        if (time >= maxTime)
        {
            missileChase();
        }
    }
    void missileChase()
    {
        rig.useGravity = false;
        rig.velocity = Vector3.zero;
        transform.position += Vector3.back * 10 * Time.deltaTime;
    }
}
