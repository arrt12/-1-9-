using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed;
    public float destroyTime;
    Player Player;
    Monster monster;
    Boss midBoss;
    EndBoss endBoss;
    [SerializeField] bool isBoss = false;
    enum Monsterbullet
    {
        monsterBt,
        bossBt,
        playerBt,
    }
    [SerializeField]Monsterbullet monsterbullet;

    void Start()
    {
        switch (monsterbullet)
        {
            case Monsterbullet.monsterBt:
                isBoss = false;
                break;
            case Monsterbullet.bossBt:
                isBoss = true;
                break;
        }
    }
    void Update()
    {
        transform.Translate(new Vector3(0, 0, speed * Time.deltaTime));
        Destroy(gameObject, destroyTime);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other == null)
            return;
        if (other.gameObject.CompareTag("Player"))
        {
            if (monsterbullet == Monsterbullet.playerBt)
                return;
            Player = other.GetComponent<Player>();
            Player.Hit(Player.MonsterBulletDamage);
            Destroy(gameObject);
        }
        if (other.gameObject.CompareTag("Monster"))
        {
            if (monsterbullet == Monsterbullet.monsterBt)
                return;
            if (monsterbullet == Monsterbullet.bossBt)
                return;
            monster = other.GetComponent<Monster>();
            monster.Hit(10);
            Destroy(gameObject);
        }
        if (other.gameObject.CompareTag("MidBoss") && !isBoss)
        {
            if (monsterbullet == Monsterbullet.monsterBt)
                return;
            if (monsterbullet == Monsterbullet.bossBt)
                return;
            midBoss = other.gameObject.GetComponent<Boss>();
            midBoss.Hit(10);
            Destroy(gameObject);
        }
        if (other.gameObject.CompareTag("EndBoss") && !isBoss)
        {
            if (monsterbullet == Monsterbullet.monsterBt)
                return;
            if (monsterbullet == Monsterbullet.bossBt)
                return;
            print("���� �ǰ�");
            endBoss = other.gameObject.GetComponent<EndBoss>();
            endBoss.Hit(10);
            Destroy(gameObject);
        }
    }
}
