using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossDead : MonoBehaviour
{
    Boss boss;
    [SerializeField] GameObject destructionEffect;//�ı� ����Ʈ
    [SerializeField] GameObject bossObject;
    private void Awake()
    {
        boss = GetComponent<Boss>(); 
    }

    void Start()
    {    
    }

    void Update()
    {   
        BossHp();
    }
    void BossHp()
    {
        if (boss.Hp <= 0)
        {
            destructionEffect.SetActive(true);
            bossObject.SetActive(false);
            Destroy(gameObject,1f);
        }
    }
}
