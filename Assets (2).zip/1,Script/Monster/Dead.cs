using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dead : MonoBehaviour
{
    Moster Monster;
    [SerializeField] GameObject destructionEffect;//�ı� ����Ʈ
    [SerializeField] GameObject bossObject;
    private void Awake()
    {
        Monster = GetComponent<Moster>();
    }

    void Start()
    {
    }

    void Update()
    {
        BossHp();
    }
    void BossHp()
    {
        if (Monster.Hp <= 0)
        {
            destructionEffect.SetActive(true);
            bossObject.SetActive(false);
            Destroy(gameObject, 3f);
        }
    }
}
