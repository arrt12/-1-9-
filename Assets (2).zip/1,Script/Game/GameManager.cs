using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    Vector3 pos;
    [SerializeField] float moveSpeed = 10f;
    public RectTransform rect;
    bool isStart;
    public enum GameState
    {
        starting,
        gaming,
    }
    public GameState gameState;
    void Start()
    {
        gameState = GameState.starting;
    }

    void Update()
    {
        if (isStart)
        {
            rect.anchoredPosition = Vector2.Lerp(rect.anchoredPosition, new Vector3(0, -750, 0), moveSpeed * Time.deltaTime);
            if (rect.anchoredPosition.y <= -749)
            {
                rect.anchoredPosition = new Vector3(0, -750, 0);
                isStart = false;
                gameState = GameState.gaming;
            }
        }
    }
    
    public void StartButton()
    {
        print("Start");
        isStart = true;
    }
    public void ExitButton()
    {
        print("exit");
        Application.Quit();
    }
    public void SettingButton()
    {
        print("seting");
    }
}
