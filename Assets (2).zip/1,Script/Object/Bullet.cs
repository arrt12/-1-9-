using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed;
    public float destroyTime;
    Player Player;
    Moster monster;
    Boss midBoss;
    [SerializeField] bool isBoss = false;
    enum Monsterbullet
    {
        monsterBt,
        bossBt,
    }
    [SerializeField]Monsterbullet monsterbullet;

    void Start()
    {
        switch (monsterbullet)
        {
            case Monsterbullet.monsterBt:
                isBoss = false;
                break;
            case Monsterbullet.bossBt:
                isBoss = true;
                break;
        }
    }
    void Update()
    {
        transform.Translate(new Vector3(speed * Time.deltaTime, 0,0));
        Destroy(gameObject, destroyTime);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other == null)
            return;
        if (other.gameObject.CompareTag("Player"))
        {
            Player = other.GetComponent<Player>();
            Player.Hit(Player.MonsterBulletDamage);
            Destroy(gameObject);
        }
        if (other.gameObject.CompareTag("Monster"))
        {
            monster = other.GetComponent<Moster>();
            monster.Hit(10);
            Destroy(gameObject);
        }
        if (other.gameObject.CompareTag("MidBoss") && !isBoss)
        {
            midBoss = other.gameObject.GetComponent<Boss>();
            midBoss.Hit(10);
            Destroy(gameObject);
        }
    }
}
