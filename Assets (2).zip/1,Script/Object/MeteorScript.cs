using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteorScript : MonoBehaviour
{ 
    int count;
    public bool isMove;
    [SerializeField]float Starttime;
    [SerializeField]float MaxStartime;
    public GameObject atRange;
    public GameObject metear;

    void Update()
    {
        attackRange();        
    }

    void attackRange()
    {
        Starttime += Time.deltaTime;
        if (count <= 17)
        {
            if (Starttime >= MaxStartime)
            {
                count++;
                Starttime = 0;
            }
            if (count % 2 == 0)//¦��
            {
                atRange.SetActive(true);
            }
            else//Ȧ��
            {
                atRange.SetActive(false);
            }
        }
        else
        {
            isMove = true;
            metear.SetActive(true);
            Destroy(atRange);
        }
    }
}
